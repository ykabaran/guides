import { Application as BaseApplication } from "@yildizkabaran/app_tools";
import WebPushService from "./service/WebPushService.js";
import WebPushHandler from "./handler/WebPushHandler.js";

class Application extends BaseApplication {

	loadLibs(){
		super.loadLibs();
		this.addAppLib({
			class_definitions: {
				"service#web_push": WebPushService,
				"handler#web_push": WebPushHandler
			}
		});
	}

}

export default Application;