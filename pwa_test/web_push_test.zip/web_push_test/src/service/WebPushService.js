import { ServiceResponse, BasicWorker, JsonUtil, FileUtil, SynchronizationLock, IDUtil } from "@yildizkabaran/app_tools";

class WebPushService {

	constructor({ service_config }){
		this.service_config = JsonUtil.deepMerge({
			stop_timeout: 5000,
			subscriptions_file: "./temp/subscriptions.json",
			lock_acquire_timeout: 30000,
			server_vapid_details: {
				subject: 'mailto:yildiz@highlevelsoftware.com',
				publicKey: 'BJ_7EexZJthghP8XA62XKkuOqtoh6wnMwNjukIbAARok1DhiXVD5HiXw0XUu4D_QCIy9jfH_FUmTJPHFOPhBfIQ',
				privateKey: 'slJ7US1OLceNOiRcMnjXsXPKY94qIchSTpf08uB3yNM'
			}
		}, service_config);

		this.current_subscriptions = null;
		this.subscriptions_lock = new SynchronizationLock();
	}

	onSpanReady(){
		this.worker = this.makeChild({
			name: `worker#temp`,
			childClass: BasicWorker,
			options: {
				worker_config: {
					period: 60 * 1000, // every minute
					startDelay: 10 * 1000
				},
				action_fn: async (span) => { return await this.sendNotifications(span); }
			}
		});
	}

	async start(){
		await this.subscriptions_lock.acquire("file", this.service_config.lock_acquire_timeout, this);
		try {
			this.current_subscriptions = await FileUtil.readJsonFile(this.service_config.subscriptions_file);
		} catch(e){
			this.current_subscriptions = {};
			this.onError("subscriptions_file_not_found", null, e);
		} finally {
			this.subscriptions_lock.release("file");
		}
		this.worker.start();
	}

	async stop(){
		const outcomes = await Promise.allSettled([ this.worker.stop(this.service_config.stop_timeout) ]);
		this.logRejectedPromiseOutcomes("child_stop_failed", outcomes);
	}

	async registerSubscription(data, span){
		data.subscriber_id = data.subscriber_id || IDUtil.newId();
		const subscriber_id = data.subscriber_id;
		await this.subscriptions_lock.acquire("file", this.service_config.lock_acquire_timeout, span);
		try {
			this.current_subscriptions[subscriber_id] = data;
			await FileUtil.writeJsonFile(this.service_config.subscriptions_file, this.current_subscriptions);
		} catch(e){
			this.logError("subscriptions_file_write_failed", null, e);
		} finally {
			this.subscriptions_lock.release("file");
		}
		return ServiceResponse.success({ subscriber_id });
	}

	async sendNotifications(span){
		const now = Date.now();
		await this.subscriptions_lock.acquire("file", this.service_config.lock_acquire_timeout, span);
		try {
			for(const subscriber_id in this.current_subscriptions){
				const data = this.current_subscriptions[subscriber_id];
				continue;
				// send the notification if needed
				const response = await webpush.sendNotification(data.subscription, 'You have a new VAPID notification!', {
					vapidDetails: this.service_config.server_vapid_details,
					timeout: 30000,
					TTL: 60
				});
				// check the response and update the subscription if needed
			}
			await FileUtil.writeJsonFile(this.service_config.subscriptions_file, this.current_subscriptions);
		} catch(e){
			this.logError("subscriptions_file_write_failed", null, e);
		} finally {
			this.subscriptions_lock.release("file");
		}
		return ServiceResponse.success();
	}

}

export default WebPushService;