import { BaseHandler, JsonUtil } from "@yildizkabaran/app_tools";

class WebPushHandler extends BaseHandler {

	constructor({ mapping_config, service_config }){
		super(...arguments);
		this.mapping_config = JsonUtil.deepMerge(this.mapping_config, {
			base_path: "/web_push",
			methods: {
				registerSubscription: {
					path: "register"
				}
			}
		}, mapping_config);

		this.service_config = JsonUtil.deepMerge({
			service_name: "web_push"
		}, service_config);
	}

	getService(){
		return this.app.services[this.service_config.service_name];
	}

	async registerSubscription(req, res, span){
		return await this.getService().registerSubscription(req.body, span);
	}

}

export default WebPushHandler;