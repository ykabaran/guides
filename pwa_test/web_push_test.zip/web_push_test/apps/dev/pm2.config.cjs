module.exports = {
	apps: [{
		name: "web_push_test",
		script: "./run.js",
		env: {},
		node_args: [
			"--max_old_space_size=2000"
		]
	}]
}