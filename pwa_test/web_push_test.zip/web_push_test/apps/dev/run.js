import { Application } from "../../index.js";
Application.go(Application);