import Application from "./src/Application.js";

export {	
	Application
};