module.exports = {
	apps: [{
		name: "app_name",
		script: "./run.js",
		env: {
			UV_THREADPOOL_SIZE: 16
		},
		node_args: [
			"--max_old_space_size=4000"
		]
	}]
}