import { Application } from "../../index.js";

// pm2.config.js file
process.env.UV_THREADPOOL_SIZE = 16;

Application.go(Application);