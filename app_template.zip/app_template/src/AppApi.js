/**
 * @typedef Api~AppApi
 * 
 */