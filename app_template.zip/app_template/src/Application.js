import { Application as BaseApplication } from "@yildizkabaran/app_tools";

/**
 * @external AppTools
 * @desc
 * module @yildizkabaran/app_tools
 * @see {@link AppTools.index | JSDocs}
 */

/**
 * @namespace Core
 * @see {@link AppTools.Core | Core}
 */

/**
 * @namespace Database
 * @see {@link AppTools.Database | Database}
 */

/**
 * @namespace Database.Entity
 * @see {@link AppTools.Database.Entity | Database.Entity}
 */

/**
 * @namespace Service
 * @see {@link AppTools.Service | Service}
 */

/**
 * @namespace Handler
 * @see {@link AppTools.Handler | Handler}
 */

/**
 * @namespace Util
 * @see {@link AppTools.Util | Util}
 */

/**
 * @namespace Api
 * @see {@link AppTools.Api | Api}
 */

export const APPLICATION_CLASS_DEFINITIONS = {
};

/**
 * @extends AppTools.Core.Application
 * @memberof Core
 */
class Application extends BaseApplication {

	/**
	 * @see {@link AppTools.Core.Application#getChildClass | Application.getChildClass}
	 */
	getChildClass(name){
		return APPLICATION_CLASS_DEFINITIONS[name] || super.getChildClass(name) || null;
	}

}

export default Application;