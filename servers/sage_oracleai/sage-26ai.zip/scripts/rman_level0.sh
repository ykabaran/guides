#!/bin/bash
exec /bin/bash "${BASH_SOURCE[0]%/*}/rman_backup.sh" 0 "$@"
