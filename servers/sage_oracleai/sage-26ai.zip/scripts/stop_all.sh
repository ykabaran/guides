#!/bin/bash
set -eu
unset TWO_TASK
. "${BASH_SOURCE[0]%/*}/setEnv.sh"

exec "$ORACLE_HOME/bin/sqlplus" -L -s -R 3 '/ as sysdba' <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
shutdown immediate
exit success
SQL
