#!/bin/bash
set -eu
umask 077
unset TWO_TASK

case "${1:-}" in
    0|1) level=$1 ;;
    *) printf 'Usage: %s 0 [--cleanup] | 1\n' "$0" >&2; exit 2 ;;
esac

cleanup=false
if [[ $# -gt 1 ]]; then
    if [[ $# -ne 2 || $level != 0 || $2 != --cleanup ]]; then
        printf 'Usage: %s 0 [--cleanup] | 1\n' "$0" >&2
        exit 2
    fi
    cleanup=true
fi

script_dir="${BASH_SOURCE[0]%/*}"
. "$script_dir/setEnv.sh"

for mount in /uora /uoradata /uorafra /uorabackup; do
    mountpoint -q "$mount" || { printf 'Missing filesystem: %s\n' "$mount" >&2; exit 1; }
done

exec 9>"$RMAN_LOGS/.rman.lock"
flock -n 9 || { echo 'Another RMAN job holds the backup lock.' >&2; exit 1; }

logfile=$(mktemp "$RMAN_LOGS/rman_level${level}_$(date +%Y%m%d_%H%M%S)_XXXXXXXX.log")
run_backup() {
    local state
    state=$("$ORACLE_HOME/bin/sqlplus" -L -s -R 3 '/ as sysdba' <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
set heading off feedback off pagesize 0
select upper(db_unique_name) || ':' || database_role || ':' || open_mode || ':' || log_mode
from v$database;
exit success
SQL
    ) || { printf '%s\n' "$state"; return 1; }

    if [[ "${state//[[:space:]]/}" != "${ORACLE_UNQNAME^^}:PRIMARY:READWRITE:ARCHIVELOG" ]]; then
        printf 'Backup requires %s open read-write as PRIMARY in ARCHIVELOG mode. Got: %s\n' \
            "$ORACLE_UNQNAME" "$state"
        return 1
    fi

    "$ORACLE_HOME/bin/rman" target / nocatalog cmdfile="$script_dir/level${level}.rmn"
}

if run_backup >"$logfile" 2>&1; then
    printf 'RMAN level %s completed. Log: %s\n' "$level" "$logfile"
else
    rc=$?
    printf 'RMAN level %s failed (%s). Log: %s\n' "$level" "$rc" "$logfile" >&2
    exit "$rc"
fi

# Keep descriptor 9 locked through maintenance so a level 1 cannot overlap it.
if [[ "$cleanup" == false ]]; then
    exit 0
fi

logfile=$(mktemp "$RMAN_LOGS/rman_cleanup_$(date +%Y%m%d_%H%M%S)_XXXXXXXX.log")
run_cleanup() {
    local mount check
    for mount in /uorafra /uorabackup; do
        mountpoint -q "$mount" || { printf 'Missing filesystem: %s\n' "$mount"; return 1; }
    done

    check=$("$ORACLE_HOME/bin/sqlplus" -L -s -R 3 '/ as sysdba' <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
set heading off feedback off pagesize 0
select case
    when upper(db_unique_name) <> 'SAGE' or database_role <> 'PRIMARY'
        or open_mode <> 'READ WRITE' or log_mode <> 'ARCHIVELOG'
        then 'Expected the open SAGE primary in ARCHIVELOG mode'
    when exists (
        select 1 from v$archive_dest
        where target = 'STANDBY' and destination is not null
    ) then 'Standby archive destination configured'
    when not exists (
        select 1 from v$rman_configuration
        where name = 'RETENTION POLICY'
          and regexp_like(upper(trim(value)), '(^|[[:space:]])RECOVERY WINDOW OF 7 DAYS$')
    ) then 'Configure the seven-day RMAN recovery window first'
    else 'READY'
end
from v$database;
exit success
SQL
    ) || { printf '%s\n' "$check"; return 1; }

    if [[ "${check//[[:space:]]/}" != READY ]]; then
        printf 'Cleanup refused: %s\n' "$check"
        return 1
    fi

    "$ORACLE_HOME/bin/rman" target / nocatalog cmdfile="$script_dir/rman_cleanup.rmn"
}

if run_cleanup >"$logfile" 2>&1; then
    printf 'RMAN cleanup completed. Log: %s\n' "$logfile"
else
    rc=$?
    printf 'Level 0 completed. RMAN cleanup failed or was refused (%s). Log: %s\n' "$rc" "$logfile" >&2
    exit "$rc"
fi
