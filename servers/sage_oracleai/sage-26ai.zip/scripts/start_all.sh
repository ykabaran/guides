#!/bin/bash
set -eu
unset TWO_TASK
. "${BASH_SOURCE[0]%/*}/setEnv.sh"

for mount in /uora /uoradata /uorafra; do
    mountpoint -q "$mount" || { printf 'Missing filesystem: %s\n' "$mount" >&2; exit 1; }
done

sqlplus=("$ORACLE_HOME/bin/sqlplus" -L -s -R 3 '/ as sysdba')
"${sqlplus[@]}" <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
startup mount
exit success
SQL

# V$DATABASE can be queried while mounted. Check its result in Bash.
if ! role=$("${sqlplus[@]}" 2>&1 <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
set heading off feedback off pagesize 0
select database_role from v$database;
exit success
SQL
); then
    printf 'Could not check the mounted database role:\n%s\n' "$role" >&2
    exit 1
fi

if [[ "${role//[[:space:]]/}" != PRIMARY ]]; then
    printf 'Primary start refused. Mounted database role: %s\n' "$role" >&2
    exit 1
fi

exec "${sqlplus[@]}" <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
alter database open;
exit success
SQL
