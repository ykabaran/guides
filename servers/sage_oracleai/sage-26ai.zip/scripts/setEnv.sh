# Source this file from Bash.
export ORACLE_BASE=/uora/app/oracle
export ORACLE_HOME="$ORACLE_BASE/product/23.0.0/dbhome_1"
export ORACLE_HOSTNAME=sage.hlsd.com
export ORACLE_SID=sage
export ORACLE_UNQNAME=sage
export RMAN_LOGS=/uorabackup/logs
export NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS'

case "$PATH" in
    "$ORACLE_HOME/bin"|"$ORACLE_HOME/bin:"*) ;;
    *) export PATH="$ORACLE_HOME/bin:$PATH" ;;
esac

# Conventional local paths. Run oracle_paths to confirm the active files.
_oracle_config="$ORACLE_HOME"
if [[ -x "$ORACLE_HOME/bin/orabaseconfig" ]]; then
    _oracle_detected=$("$ORACLE_HOME/bin/orabaseconfig" 2>/dev/null) &&
        [[ "$_oracle_detected" = /* ]] && _oracle_config="$_oracle_detected"
fi
export P_FILE="$_oracle_config/dbs/init${ORACLE_SID}.ora"
export SP_FILE="$_oracle_config/dbs/spfile${ORACLE_SID}.ora"
export ALERT_LOG="$ORACLE_BASE/diag/rdbms/$ORACLE_UNQNAME/$ORACLE_SID/trace/alert_${ORACLE_SID}.log"
unset _oracle_config _oracle_detected

oracle_paths() {
    env -u TWO_TASK "$ORACLE_HOME/bin/sqlplus" -L -s -R 3 '/ as sysdba' <<'SQL'
whenever oserror exit failure
whenever sqlerror exit failure
set linesize 220
show parameter spfile
column name format a150
select name from v$controlfile order by name;
column name format a24
column value format a150
select name, value from v$diag_info where name in ('Diag Trace', 'Diag Alert');
exit success
SQL
}
