# Oracle Database 26ai on sage

This bundle targets Oracle Linux 9, an image-based 23.26.1 Oracle home, and a standalone CDB. It assumes a dedicated Oracle Net listener named LISTENER. The database and listener units are installed after DBCA. The commands below are run on sage.hlsd.com from the extracted bundle directory unless specified otherwise.

## Before installation

For each path, verify its exact mount and match its source to the intended 60 GiB LV in vg_oracle. Check that these are persistent mounts in /etc/fstab.

```bash
sudo lvs -o vg_name,lv_name,lv_size,lv_path vg_oracle
for mount in /uora /uoradata /uorafra /uorabackup; do
    findmnt --mountpoint "$mount" -o TARGET,SOURCE,FSTYPE,OPTIONS
done
df -h /uora /uoradata /uorafra /uorabackup
```

On the verified empty filesystems, create the directories as follows. This changes the named directories only.

```bash
(
    set -e
    for mount in /uora /uoradata /uorafra /uorabackup; do
        mountpoint -q "$mount" || { echo "Missing mount: $mount" >&2; exit 1; }
    done
    sudo install -d -o oracle -g oinstall -m 0755 \
        /uora/app /uora/app/oracle /uora/app/oracle/product/23.0.0/dbhome_1
    sudo install -d -o oracle -g oinstall -m 0775 /uora/app/oraInventory
    sudo install -d -o oracle -g oinstall -m 0750 /uoradata /uorafra /uorabackup
    sudo install -d -o oracle -g oinstall -m 0700 \
        /uorabackup/rman /uorabackup/logs /home/oracle/scripts
    sudo install -o oracle -g oinstall -m 0700 \
        scripts/start_all.sh scripts/stop_all.sh scripts/rman_*.sh /home/oracle/scripts/
    sudo install -o oracle -g oinstall -m 0600 \
        scripts/setEnv.sh scripts/*.rmn scripts/login.sql rman-config.rmn /home/oracle/scripts/
)
```

As oracle, append the block in bash_profile.addition to /home/oracle/.bash_profile once, after the existing PATH setup. Sign in again. Confirm hostname -f returns sage.hlsd.com.

Install the database image in /uora/app/oracle/product/23.0.0/dbhome_1. Configure the standalone CDB in DBCA with SID sage, DB_NAME sage, DB_UNIQUE_NAME sage, database storage on /uoradata, and the FRA on /uorafra. Choose the PDB name separately. A 50 GiB FRA quota is a starting point if the FRA volume is dedicated and has at least 55 GiB free. Use an SPFILE and a password file.

For Oracle paths after DBCA, use oracle_paths from your login shell. P_FILE and SP_FILE point to the conventional default locations for this Oracle home. ALERT_LOG is the expected text alert path. Use the Diag Trace value from oracle_paths if the database uses a different diagnostic base. The same command lists every live control-file path. SQL*Plus reads login.sql in interactive oracle logins for the preferred DATE display.

## Bring systemd online after DBCA

In a local SQL*Plus SYSDBA session, check the identity and archive mode. If DBCA created the CDB in NOARCHIVELOG mode, run the four lines in the second block while systemd is still out of the picture.

```sql
select name, db_unique_name, database_role, log_mode, force_logging from v$database;
show parameter db_recovery_file_dest
show parameter spfile
show parameter remote_login_passwordfile
```

```sql
shutdown immediate
startup mount
alter database archivelog;
alter database open;
```

Run `ALTER DATABASE FORCE LOGGING;` in the CDB root now to prepare for a physical standby. Open the intended PDBs and save their state, if you want those PDBs to reopen at primary startup. Verify that the listener is the dedicated LISTENER. If DBCA started it and the instance, shut down the database with SHUTDOWN IMMEDIATE and stop the listener as oracle before the first systemd start.

```bash
sudo install -o root -g root -m 0644 systemd/*.service /etc/systemd/system/
sudo systemd-analyze verify /etc/systemd/system/oracle-sage{,-listener}.service
sudo systemctl daemon-reload
sudo systemctl start oracle-sage.service
sudo systemctl status oracle-sage.service oracle-sage-listener.service
sudo systemctl stop oracle-sage.service
sudo systemctl start oracle-sage.service
sudo systemctl enable oracle-sage.service
```

Confirm the instance and intended PDBs after the restart with SQL*Plus and check services with lsnrctl status LISTENER. These are oneshot units, so active (exited) means the start command succeeded. To investigate, use journalctl -u oracle-sage.service -u oracle-sage-listener.service. KillMode=process deliberately leaves Oracle background processes alone if graceful shutdown fails. Check the actual instance state after a failed start or stop before retrying. If startup failed and the instance is still mounted or open, use SQL*Plus as oracle to shut it down cleanly before starting the unit again. The startup script checks the mounted database role with a SQL query before opening it. The shipped 3 GiB memlock limit is for a host without HugePages. If you use HugePages, adjust the unit limit to match your Oracle Linux memory plan.

## Run and schedule RMAN

As oracle, after ARCHIVELOG is enabled and the primary is open read-write, run:

```bash
for level in 0 1; do
    "$ORACLE_HOME/bin/rman" CHECKSYNTAX CMDFILE="$HOME/scripts/level${level}.rmn" || break
done
"$ORACLE_HOME/bin/rman" target / nocatalog
```

Proceed after both syntax checks pass. In the connected RMAN session, confirm the connection banner identifies sage and record the DBID off-host. Run:

```text
@/home/oracle/scripts/rman-config.rmn
EXIT
```

The settings file enables disk control-file autobackups under /uorabackup/rman/%F and uses BASIC compression. Both backup jobs save archived redo before and after the datafile backup. Each archived log is backed up once to disk according to the RMAN repository. Use independent off-host copies of the backup pieces and autobackups.

Run /home/oracle/scripts/rman_level0.sh manually first. Check its exit status and log. Check LIST BACKUP SUMMARY and RESTORE DATABASE VALIDATE in RMAN, then test recovery separately with archived redo. Confirm free space on both /uorafra and /uorabackup, and verify that the backup LV can fit an incoming level 0 while your existing recoverable chain is still on disk.

Merge oracle.crontab into oracle's existing crontab with sudo crontab -u oracle -e. Confirm crond is running and that cron mail reaches an operator, or arrange failure monitoring for these jobs. Job output includes the unique RMAN log filename. The schedule runs at 02:15 host local time, with a level 0 on Sunday and differential level 1 on the other days. It copies archived redo during those nightly jobs. A shorter off-host recovery window calls for more frequent archived redo backup and transfer.

### Optional maintenance after Sunday's level 0

A seven-day recovery window is a starting policy for point-in-time recovery when storage can hold it. RMAN retains the level 0 needed to reach the beginning of that window, along with the level 1 and archived redo dependencies. With weekly level 0s and cleanup only after the next one succeeds, budget for three level 0s in flight at the Sunday peak, plus retained incrementals, archived redo, autobackups, other files, and growth. A delayed or missed backup can raise usage further. Measure real jobs with df -h /uorabackup and du -sh /uorabackup/rman /uorabackup/logs. Expand the volume or use an off-host backup tier if it cannot fit the window you need.

In RMAN connected to SAGE, preview the policy with:

```text
REPORT OBSOLETE RECOVERY WINDOW OF 7 DAYS;
```

After confirming the space budget, configure the window:

```text
CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 7 DAYS;
SHOW RETENTION POLICY;
REPORT OBSOLETE;
```

The recovery window builds up as backups and redo accumulate. It does not give a new database seven days of history immediately. With NOCATALOG, review CONTROL_FILE_RECORD_KEEP_TIME and make it longer than the age of the oldest backup you plan to keep. An initial 21 days is reasonable if backup history normally stays within two weeks.

As oracle, syntax-check the separate maintenance file:

```bash
"$ORACLE_HOME/bin/rman" CHECKSYNTAX CMDFILE="$HOME/scripts/rman_cleanup.rmn"
```

To turn on maintenance, replace the Sunday cron line with the commented --cleanup example in oracle.crontab. Keep one Sunday entry. This runs a separate RMAN maintenance session after the level 0 exits successfully and uses the same lock through both operations. It logs the report and deletion separately in /uorabackup/logs. A failed backup skips cleanup. A cleanup failure leaves the successful backup in place and is reported separately. The job requires the explicitly configured seven-day recovery window and refuses cleanup if it detects a standby archive destination.

DELETE OBSOLETE DEVICE TYPE DISK applies to SAGE's disk backups across known locations and can also remove obsolete archived redo files in the FRA. Keep independently recoverable off-host copies. Remove --cleanup from Sunday cron before configuring Data Guard and review how to protect standby redo apply before re-enabling maintenance.

## Physical standby later

Keep DB_NAME sage on both databases, and assign the standby a distinct DB_UNIQUE_NAME such as sage_stby. Keep the primary's DB_UNIQUE_NAME sage even after a role change. Confirm edition and licensing before deployment. Redo Apply on a mounted standby is available with on-premises Enterprise Edition. Read-only real-time query while applying redo requires checking the Active Data Guard license.

Once the standby host is chosen, size standby redo logs on both sides from the actual online redo groups. Configure password-file authentication, Oracle Net, redo transport, and Data Guard Broker. Choose synchronous or asynchronous transport using the acceptable data loss and network latency. Confirm transport lag and apply lag and account for both backup copies and standby apply before enabling any archive deletion policy. The service in this bundle opens only a primary. Plan standby startup and the backup schedule on the new primary before the first switchover.
